<?php
$page = "file";
session_start();
include('config.php');
include('header.php');
error_reporting(1);



extract($_POST);

$target_dir = "test_upload/";

$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

if($upd)
{
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

    /* if($imageFileType != "mp4" && $imageFileType != "avi" && $imageFileType != "mov" && $imageFileType != "3gp" && $imageFileType != "mpeg")
    {
        echo "File Format Not Suppoted";
    }

    else
    { */

    $video_path=$_FILES['fileToUpload']['name'];
    $query1 = mysql_query("SELECT c.id,c.name as college_name,d.id,d.name as department_name,s.id,s.name as section_name,u.name as username,u.clg_id,u.dept_id,u.section_id,u.role from
college c,department d,section s,users u where c.id=u.clg_id and d.id=u.dept_id and s.id=u.section_id and u.id='{$_SESSION['uid']}'");
    $row = mysql_fetch_array($query1);
    $query = mysql_query("INSERT INTO `video`( `video_name`, `uploaded_by`,`category`,`clg_id`, `dept_id`, `section_id`,`from_clg`,`from_dept`,`from_section`)
VALUES('{$video_path}','{$_SESSION['username']}','{$_POST['category']}','{$_POST['coll']}','{$_POST['dept']}','{$_POST['section']}','{$row['college_name']}','{$row['department_name']}','{$row['section_name']}')");
    if($query) {
        move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$target_file);

        echo "<script>alert('Video Uploaded Successfully!!');</script> ";
    }
    else
    {
        die(mysql_error());
    }
//}

}

//display all uploaded video

if($disp)

{

    $query=mysql_query("SELECT * FROM video ORDER BY v_id DESC LIMIT 1");

    while($all_video=mysql_fetch_array($query))

    {
        ?>
        <center>
            <video width="600" height="400" controls>
                <source src="test_upload/<?php echo $all_video['video_name']; ?>" type="video/mp4">
            </video>
        </center>
    <?php } } ?>

<html>
<head>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
    <script>
        function selectDept(val) {

            $.ajax({
                type: "GET",
                url: "getDepartment.php",
                cache:false,
                data: "collegeid=" + val,
                success: function (data) {

                    $('#department_list').html(data);
                }
            });
        }
    </script>
    <script>
        function getSection(val) {

            $.ajax({
                type:"GET",
                url:"getSection.php",
                cache:false,
                data:"deptid="+val,
                success:function(data) {

                    $("#section_list").html(data);
                }
            });
        }
    </script>
    <script>
        $(function(){
            $("#upd").click(function(){
                $("#disp").show();
            });
        });
    </script>

</head>
<body>
<form method="post" enctype="multipart/form-data">
    <div class="container">
        <div class="col-md-6 m-t-10">
            <div class="form-group">
                <label>Select College</label>
                <select name = "coll" onchange = "selectDept(this.value)"  class="form-control" >
                    <option value="">Select College</option>
                    <?php
                    include('config.php');
                    $q6 = mysql_query("select * from college where status=1");
                    while($r = mysql_fetch_array($q6)) {

                        echo '<option value = '.$r["id"].'>'.strtoupper($r['name']).'</option>';

                    }

                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Select Department</label>
                <select name = "dept" id="department_list" class="form-control" onchange = "getSection(this.value)">

                </select>
            </div>
            <div class="form-group">
                <label>Section</label>
                <select class="form-control" id="section_list" name="section">

                </select>
            </div>
            <div class="form-group">
                <label>Category</label>
                <select class="form-control" name="category" required>
                    <option value="">Select Category</option>
                    <?php
                    $query = mysql_query("select * from category where status=1");
                    while($row = mysql_fetch_array($query)) {
                        ?>
                        <option value="<?php echo strtoupper($row['cat_name']); ?>"><?php echo strtoupper($row['cat_name']); ?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Upload Video</label>
                <input type="file" class="form-control" name="fileToUpload"/>
            </div>
            <div class="form-group">

                <input type="submit" value="Submit" class="btn btn-primary" name="upd" id="upd"/>

                <input type="hidden" value="Preview Video" class="btn btn-info" id="disp" name="disp" />
            </div>

        </div>
    </div>

</form>
</body>
</html>