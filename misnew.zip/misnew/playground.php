<?php
	include('config.php');
	include('common/header.php');
?>
<div class="tab-content" id="h4 tab1">
	<div id="home4" class="tab-pane in active">
		<div class="row">
			<div><!--form start-->
				<form action="" class="form-horizontal" role="form">
					<div class="form-group" >
						<label class="col-sm-4 control-label no-padding-right" for="form-field-1"> The playground allows free-form programming.</label>
					</div>
					<br>
					<div class="col-md-offset-2 col-md-4">
						<a href="../user/code.php" class="btn btn-primary btn-lg">Enter the playground</a>
					</div>
					<!--	<div class="col-md-offset-0 col-md-0">
					<button class="btn" type="reset">
					<i class="ace-icon fa fa-undo bigger-110"></i>
					Reset
					</button>
					</div>-->
				</form>
			</div>
		</div>
	<!--php script for live table-->
	<br><br><br><br><br><br><br><br><br><br>
	<div  class="space"></div>
	<?php include('common/footer.php'); ?>

</body>
</html>