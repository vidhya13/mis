
<html lang="en">
<head>
  <title>KGiSL SSA</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
  <style>
    .un
    {
      padding-left:300px;
    }
    .l
    {
      padding-left:50px;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KGiSL SSA</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="<?php echo ($page == "home" ? "active" : "")?>"><a href="first.php">Home</a></li>
      <?php if($_SESSION['role'] == "Admin" || $_SESSION['role'] == "SSA Admin") {?>
        <li class="<?php echo ($page == "college" ? "active" : "")?>"><a href="college.php">Add College</a></li>
        <li class="<?php echo ($page == "role" ? "active" : "")?>"><a href="add_role.php">Add Roles</a></li>
        <li class="<?php echo ($page == "pro_det" ? "active" : "")?>"><a href="pro_det.php">Add User</a></li>
        <li class="<?php echo ($page == "category" ? "active" : "")?>"><a href="category.php">Add Category</a></li>

        <li class="<?php echo ($page == "file" ? "active" : "")?>"><a href="file.php">Blogs</a></li>
      <?php } if(strtoupper($_SESSION['role'])!='STUDENT') {?>
        <li class="<?php echo ($page == "view_file" ? "active" : "")?>"><a href="view_files.php">View Blogs</a></li>
      <?php } else {?>
        <li class="<?php echo ($page == "std_view_file" ? "active" : "")?>"><a href="std_view_files.php">View Blogs</a></li>
      <?php } ?>
    </ul>
    <div class="un">
      <a class="navbar-brand un" href="#"> Welcome <b><?php echo $_SESSION['username']; ?></b></a>
      <a class="navbar-brand l" href="logout.php"> Logout</a>
    </div>
  </div>
</nav>

<!-- DataTables
<script src="assets/js/jquery.dataTables.min.js"></script>
<script src="assets/js/jquery.dataTables.bootstrap.min.js"></script>
<script src="assets/js/dataTables.tableTools.min.js"></script>
<script src="assets/js/dataTables.colVis.min.js"></script>
<script src="assets/js/datat.js"></script> -->
</body>
</html>