<?php
include('config.php');
if(isset($_GET['id'])) {
    $q1 = mysql_query("select * from section where id = '{$_GET['id']}'");
    $r1 = mysql_fetch_array($q1);
    $query = mysql_query("update section set status=0 where id='{$_GET['id']}'");
    if($query) {
        $q2 = mysql_query("update department set status=0 where id='{$r1['dept_id']}'");
        $q3 = mysql_query("update college set status=0 where id='{$r1['clg_id']}'");
        if($q3) {
            header('location:college.php');
        }
    }
}
?>