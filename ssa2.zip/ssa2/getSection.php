<option value="">Select Section</option>
<?php
include('config.php');
if(isset($_GET['deptid'])) {

    $did = $_GET['deptid'];
    $query = mysql_query("select DISTINCT batch from api_std where course='{$did}' and status=1");

    while($r = mysql_fetch_array($query)) {
        ?>
        <option value = '<?php echo $r['batch']; ?>' ><?php echo $r['batch']; ?></option>
        <?php
    }
}
?>