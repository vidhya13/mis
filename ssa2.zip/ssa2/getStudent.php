<option value="">Select Students</option>
<?php
include('config.php');
if(isset($_POST['batch'])) {
	$q = mysql_query("SELECT * FROM `users` WHERE clg_id='{$_POST['clg']}' and dept_id='{$_POST['dept']}' and section_id='{$_POST['sec']}' and batch = '{$_POST['batch']}'");

	while($r = mysql_fetch_array($q)) {
		?>

		<option value="<?php echo $r['id']; ?>"><?php echo $r['name']; ?></option>
		<?php
	}
}
?>