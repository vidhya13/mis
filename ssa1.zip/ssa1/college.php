<?php
session_start();
$page = "college";
include('config.php');
include('header.php');
$q1 = "";
$r1 = "";
if(!empty($_GET['id'])) {
    $q1 = mysql_query("SELECT c.id as cid,c.name as college_name,d.id as did,d.name as dept_name,s.* from college c,department d, section s where c.id=s.clg_id and d.id=s.dept_id and s.id='{$_GET['id']}'");
    $r1 = mysql_fetch_array($q1);

    if(isset($_POST['submit'])) {

        $query = mysql_query("UPDATE `section` SET `name`='{$_POST['sec']}',`dept_id`='{$r1['did']}',`clg_id`='{$r1['cid']}' WHERE id='{$_GET['id']}'");
        if($query) {
            $q1 = mysql_query("update college set name='{$_POST['clg']}' where id='{$r1['cid']}'");
            $q2 = mysql_query("UPDATE `department` SET `name`='{$_POST['dept']}',`clg_id`='{$r1['cid']}'  WHERE id='{$r1['did']}'");
            header('location:college.php');
        }

    }
} else {
    if (isset($_POST['submit'])) {
        $query ="";

        $clg_list = mysql_query("select * from college where name = '{$_POST['clg']}'");
        $list_row = mysql_fetch_array($clg_list);

        if(empty($list_row))  {
            $query = mysql_query("insert into college(`name`) values('{$_POST['clg']}')"); }
        else
        {
            $query = "";

            $query = mysql_query("update college set name='{$_POST['clg']}' where name='{$_POST['clg']}'");

        }
        if($query) {
            $clg_list = mysql_query("select * from college where name = '{$_POST['clg']}'");
            $list_row = mysql_fetch_array($clg_list);
            $dept_list = mysql_query("select * from department where name = '{$_POST['dept']}'");
            $list_row1 = mysql_fetch_array($dept_list);
            if(empty($list_row1))  {
                $dept = mysql_query(" INSERT INTO `department`(`name`,`clg_id`) VALUES ('{$_POST['dept']}','{$list_row['id']}') "); }
            else
            {
                $dept = "";
                $dept = mysql_query("UPDATE `department` SET `name`='{$_POST['dept']}',`clg_id`='{$list_row['id']}'  WHERE name='{$_POST['dept']}'");
            }
            if($dept) {

                $dept_list = mysql_query("select * from department where name = '{$_POST['dept']}'");
                $list_row1 = mysql_fetch_array($dept_list);
                $sec = mysql_query("INSERT INTO `section`(`name`, `dept_id`, `clg_id`) VALUES ('{$_POST['sec']}',{$list_row1['id']},'{$list_row1['clg_id']}')");

                if($sec) {
                    header('location:college.php');
                }
            }
        }
    } }
?>
<html>
<head>

</head>
<body>
<form method="post" action="">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-blue">

                <div class="panel-body">
                    <div class="col-md-2">

                        <label>College</label>
                        <input type="text" name="clg" <?php if(isset($_GET['id'])) { ?> value="<?php echo $r1['college_name']; ?>" <?php } ?> class="form-control" style="text-transform:uppercase" required>
                    </div>
                    <div class="col-md-2">
                        <label>Department</label>
                        <input type="text" name="dept" <?php if(isset($_GET['id'])) { ?> value="<?php echo $r1['dept_name']; ?>" <?php } ?> class="form-control" style="text-transform:uppercase" required>
                    </div>
                    <div class="col-md-2">
                        <label>Section</label>
                        <select class="form-control" name="sec" required>
                            <option value="">Select Section</option>
                            <option value="A" <?php if(isset($_GET['id']) && $r1['name']=="A") { echo 'selected'; } ?>>A</option>
                            <option value="B"  <?php if(isset($_GET['id']) && $r1['name']=="B") { echo 'selected'; } ?>>B</option>
                            <option value="C"  <?php if(isset($_GET['id']) && $r1['name']=="C") { echo 'selected'; } ?>>C</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <br>
                        <input type="submit" class="form-control btn btn-primary" name="submit" value="Submit">
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <table id="dynamic-table" class="table table-striped table-bordered table-hover table-responsive">
        <thead>
        <tr>
            <th>SNO</th>
            <th>College</th>
            <th>Department</th>
            <th>Section</th>
            <th>Actions</th>
        </tr>
        </thead>
        <?php

        $query = mysql_query("SELECT c.id as cid,c.name as college_name,d.id as did,d.name as dept_name,s.* from college c,department d, section s where c.id=s.clg_id and d.id=s.dept_id and s.status=1");
        $i=1;
        while($row = mysql_fetch_array($query)) {

            ?>
            <tbody>
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo strtoupper($row['college_name']); ?></td>
                <td><?php echo strtoupper($row['dept_name']); ?></td>
                <td><?php echo strtoupper($row['name']); ?></td>
                <td><a href="college.php?id=<?php echo $row['id']; ?>" id="ed" view='' class="btn btn-xs btn-primary" ><i class="glyphicon glyphicon-edit"></i>Edit </a>

                    <a href="delete_college.php?id=<?php echo $row['id']; ?>" class="btn btn-xs btn-danger"> <i class="glyphicon glyphicon-trash"></i>Delete</a></td>

            </tr>
            </tbody>

            <?php
            $i++;
        }
        ?>
    </table>
</form>
</body>
</html>