<?php
include('config.php');
if(isset($_GET['id'])) {
    $query = mysql_query("update video set status=0 where v_id='{$_GET['id']}'");
    if($query) {
        header('location:view_files.php');
    }
}
?>