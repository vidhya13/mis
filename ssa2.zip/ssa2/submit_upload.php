<?php

include('config.php');

if($_POST) {
    $v_name = $_POST['sid'].$_POST['upv'];

    $query = mysql_query("INSERT INTO `video1`(`v_name`, `a_name`, `r_name`, `student_id`) VALUES ('{$_POST['sid']}{$_POST['upv']}','{$_POST['sid']}{$_POST['upa']}',
	'{$_POST['sid']}{$_POST['upf']}','{$_POST['sid']}')");


}
?>

