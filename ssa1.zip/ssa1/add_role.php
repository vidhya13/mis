<?php

$page = "role";
session_start();
include('config.php');
include('header.php');
error_reporting(1);

$query = "";
$row = "";
if(!empty($_GET['id'])) {

    $query = mysql_query("select * from roles where id='{$_GET['id']}'");
    $row = mysql_fetch_array($query);

    if (isset($_POST['submit'])) {
        $q = mysql_query("UPDATE `roles` SET `role_name`='{$_POST['urole']}' WHERE id='{$_GET['id']}'");
        if($q) {
            echo "<script>alert('Role updated Susccessfully');</script>";
            header('location:add_role.php');
        }
    } } else {
    if (isset($_POST['submit'])) {
        $q = mysql_query("INSERT INTO `roles`(`role_name`) VALUES ('{$_POST['urole']}')");
        if ($q) {
            echo "<script>alert('Role added Susccessfully');</script>";
        }
    }

}
?>
<html>
<head>

</head>
<body>
<form method="post" action="">
    <div class="container">
        <div class="col-md-6 m-t-10">
            <div class="form-group">
                <label>Role</label>
                <input type="text" name="urole" <?php if(isset($_GET['id'])) { ?> value="<?php echo $row['role_name']; ?>" <?php } ?> class="form-control" style="text-transform:uppercase" required>

            </div>
            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
        </div><br>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">

                        </div>
                        <!-- /.box-header -->
                        <div class="box-body" style="margin:10px">
                            <table id="dynamic-table" class="table table-striped table-bordered table-hover table-responsive">
                                <thead>
                                <tr>
                                    <th>SNO</th>
                                    <th>Role Name</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <?php

                                $query = mysql_query("select * from roles where status=1");
                                $i=1;
                                while($row = mysql_fetch_array($query)) {

                                    ?>
                                    <tbody>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo strtoupper($row['role_name']); ?></td>
                                        <td><a href="add_role.php?id=<?php echo $row['id']; ?>" id="ed" view='' class="btn btn-xs btn-primary" ><i class="glyphicon glyphicon-edit"></i>Edit </a>

                                            <a href="delete_role.php?id=<?php echo $row['id']; ?>" class="btn btn-xs btn-danger"> <i class="glyphicon glyphicon-trash"></i>Delete</a></td>

                                    </tr>
                                    </tbody>

                                    <?php
                                    $i++;
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


</form>
</body>
</html>
