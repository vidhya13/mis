<?php
session_start();
$page = "std_view_file";
include('config.php');
include('header.php');
error_reporting(1);
$results_per_page = 10;
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }
$start_from = ($page-1) * $results_per_page;

$query = "";
$sql = "";
$category = $_POST['category1'];

if (isset($_POST['submit']) && $_POST['category1'] != "All") {


    $query = mysql_query("SELECT u.*,v.* from users u, video v WHERE u.id='{$_SESSION['uid']}' and u.clg_id =v.clg_id and
u.dept_id=v.dept_id and u.section_id=v.section_id and v.category='{$category}' order by v.v_id desc LIMIT $start_from, " . $results_per_page);
    $sql = mysql_query("SELECT u.*,v.*,count(v.v_id) as total from users u, video v WHERE u.id='{$_SESSION['uid']}' and u.clg_id =v.clg_id and
u.dept_id=v.dept_id and u.section_id=v.section_id and v.category='{$category}' order by v.v_id desc LIMIT $start_from, " . $results_per_page);
}
else {
    $query = mysql_query("SELECT u.*,v.* from users u, video v WHERE u.id='{$_SESSION['uid']}' and u.clg_id =v.clg_id and
u.dept_id=v.dept_id and u.section_id=v.section_id order by v.v_id desc LIMIT $start_from, " . $results_per_page);
    $sql = mysql_query("SELECT u.*,v.*,count(v.v_id) as total from users u, video v WHERE u.id='{$_SESSION['uid']}' and u.clg_id =v.clg_id and
u.dept_id=v.dept_id and u.section_id=v.section_id order by v.v_id desc LIMIT $start_from, " . $results_per_page);

}

?>
<html>
<head>
    <!--  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="//code.jquery.com/jquery.js"></script>
        <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script> -->
    <script>
        function selectDept(val) {

            $.ajax({
                type: "GET",
                url: "getDepartment.php",
                cache:false,
                data: "collegeid=" + val,
                success: function (data) {

                    $('#department_list').html(data);
                }
            });
        }
    </script>
    <script>
        function getSection(val) {

            $.ajax({
                type:"GET",
                url:"getSection.php",
                cache:false,
                data:"deptid="+val,
                success:function(data) {

                    $("#section_list").html(data);
                }
            });
        }
    </script>
    <script>
        $(document).ready(function(){


        });
    </script>

    <script>
        $(function() {
            $("body").on("click","[view]",function(){
                var v_id = $(this).closest("p").find("#v_id").val();

                $.ajax({
                    url:"file_edit.php?id="+v_id,
                    cache:false,
                    success:function(result){
                        $(".modal-content").html(result);
                    }
                });
                $("#userModal").modal('show');
                return false;


            });
            $("button").click(function(){

                $(this).closest("div").find("iframe").toggle();
                $(this).text(function(i, text){
                    return text === "Show Video" ? "Hide Video" : "Show Video";
                });
                return false;
            });
        });
    </script>
</head>
<body>
<form method="post" action="std_view_files.php">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-blue">
                <div class="panel-heading" style="background-color: gainsboro">
                    <div class="panel-heading-btn">


                    </div>

                    <div class="panel-body" style="background-color: gainsboro">
                        <div class="col-md-2">
                            <select name="category1" class="form-control">
                                <option>Select Category</option>
                                <option value="Project">Project</option>
                                <option value="Syllabus">Syllabus</option>
                                <option value="Study Materials">Study Materials</option>
                                <option value="All">Select All</option>
                            </select>
                        </div>
                        <?php if(strtoupper($_SESSION['role']) != 'STUDENT') { ?>
                            <div class="col-md-2">
                                <select name = "coll1" class="form-control" onchange = "selectDept(this.value)"  >
                                    <option value="">Select College</option>
                                    <?php
                                    include('config.php');
                                    $q6 = mysql_query("select * from college");
                                    while($r = mysql_fetch_array($q6)) {

                                        echo '<option value = '.$r["id"].'>'.$r['name'].'</option>';

                                    }

                                    ?>
                                    <option value="All">Select All</select>
                                </select>

                            </div>
                        <?php } ?>
                        <div class="col-md-2">
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit"><br><br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="userModal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">

                </div>

            </div>

        </div>
        <div class="row" style="margin-left:150px">
            <div class="col-xs-12">
                <div class="panel panel-blue">

                    <div class="panel-body" style="background-color: gainsboro;width:1000px">

                        <?php
                        while ($row = mysql_fetch_array($query)) {
                        //echo $row['college_name'];

                        ?>

                        <div>
                            <!--<video width="500" height="500" controls hidden>
                    <source src="test_upload/<?php /*echo $row['video_name']; */?>" type="video/mp4">
                </video>-->
                            <iframe width="640" height="360" src="test_upload/<?php echo $row['video_name']; ?>" frameborder="0" allowfullscreen hidden></iframe>
                            <button id="sho" class="btn btn-primary">Show Video</button>
                        </div>

                        <?php

                        echo "<p><b>Uploaded By:</b> <i>" . $row['uploaded_by'] . "</i> ,  ". $row['from_clg'] . ", " . $row['from_dept'] . " - " . $row['from_section'] . "  ";
                        echo "  <b>  Category:</b> " . $row['category'] . "</p>";
                        if ($_SESSION['role'] == "Admin" || $_SESSION['role'] == "SSA Admin") {
                        ?>
                        <p><input type="text" name="v_id" id="v_id" value="<?php echo $row['v_id']; ?>" hidden>
                            <?php
                            echo "<a href='' view=''>Edit </a>||";
                            echo "<a href='file_delete.php?id=" . $row['v_id'] . "' > Delete</a>";
                            echo "</p><br>";
                            }

                            }
                            echo "</div>";
                            echo "<br><br>";


                            $row = mysql_fetch_assoc($sql);

                            $total_pages = ceil($row["total"] / $results_per_page); // calculate total pages with results

                            for ($i = 1; $i <= $total_pages; $i++) {  // print links for all pages
                                echo "<b><a href='std_view_files.php?page=" . $i . "'";
                                if ($i == $page) echo " class='curPage'";
                                echo ">" . $i . "</a></b> ";
                            }

                            echo "</div></center>";
                            ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

</form>
</body>
</html>