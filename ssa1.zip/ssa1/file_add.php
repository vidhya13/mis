<?php
session_start();
include('config.php');
error_reporting(1);

extract($_POST);

$target_dir = "test_upload/";

$target_file = $target_dir . basename($_POST['image']);

if(!empty($_POST['college'])) {

    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

    $query1 = mysql_query("SELECT c.id,c.name as college_name,d.id,d.name as department_name,s.id,s.name as section_name,u.name as username,u.clg_id,u.dept_id,u.section_id,u.role from
college c,department d,section s,users u where c.id=u.clg_id and d.id=u.dept_id and s.id=u.section_id and u.id='{$_SESSION['uid']}'");
    echo "SELECT c.id,c.name as college_name,d.id,d.name as department_name,s.id,s.name as section_name,u.name as username,u.clg_id,u.dept_id,u.section_id,u.role from
college c,department d,section s,users u where c.id=u.clg_id and d.id=u.dept_id and s.id=u.section_id and u.id='{$_SESSION['uid']}'";
    $row1 = mysql_fetch_array($query1);
    if($query1) {
        $query = mysql_query("UPDATE `video` SET `video_name`='{$_POST['image']}',`uploaded_by`='{$_SESSION['username']}',
`category`='{$_POST['category']}',`clg_id`='{$_POST['college']}',`dept_id`='{$_POST['department']}',`section_id`='{$_POST['section']}',
`from_clg`='{$row1['college_name']}',`from_dept`='{$row1['department_name']}',`from_section`='{$row1['section_name']}' WHERE v_id='{$_POST['id']}'");


        echo "UPDATE `video` SET `video_name`='{$_POST['image']}',`uploaded_by`='{$_SESSION['username']}',
`category`='{$_POST['category']}',`clg_id`='{$_POST['college']}',`dept_id`='{$_POST['deptartment']}',`section_id`='{$_POST['section']}',
`from_clg`='{$row1['college_name']}',`from_dept`='{$row1['department_name']}',`from_section`='{$row1['section_name']}' WHERE v_id='{$_POST['id']}'";



        if($query) {
            move_uploaded_file($_POST['image'],$target_file);

            echo "uploaded ";
        }
        else
        {
            die(mysql_error());
        }
    }
}
//	header('location:view_files.php');

//echo "fgdfgfg";
?>