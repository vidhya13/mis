<?php

include('config.php');


if($_POST) {

$query = mysql_query("INSERT INTO `video1`(`v_name`, `a_name`, `r_name`, `student_id`) VALUES ('{$_POST['upv']}','{$_POST['upa']}',
	'{$_POST['upf']}','{$_POST['sid']}')");
	
	
}
?>

