<?php
error_reporting(1);
session_start();
$page="view_file";
include('config.php');

include('header.php');

?>
<html>
<head>
    <script>
        function selectDept(val) {
            var cid = $("#cid").val();
            $.ajax({
                type: "GET",
                url: "getDepartment.php",
                cache:false,
                data: {collegeid: val,cid:cid},
                success: function (data) {

                    $('#department_list').html(data);
                }
            });
        }
    </script>
    <script>
        function getSection(val) {
            var sid = $("#sid").val();
            $.ajax({
                type:"GET",
                url:"getSection.php",
                cache:false,
                data:{deptid:val,sid:sid},
                success:function(data) {

                    $("#section_list").html(data);
                }
            })
        }
    </script>
    <script>
        $(function(){

            $("#batch_list").change(function() {
                var clg = $("#college").val();
                var dept = $("#department_list").val();
                var sec = $("#section_list").val();
                var batch = $(this).val();

                $.ajax({
                    method:"POST",
                    url:"getStudent.php",
                    data:{clg:clg,dept:dept,sec:sec,batch:batch},
                    cache:false,
                    success:function(data) {
                        $("#students_list").html(data);
                    },
                    error:function() {

                    }
                });

            });
        });
    </script>
    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
    </script>
    <script>
        $(function() {
            $("body").on("click","[view]",function(){

                var v_id = $(this).closest("p").find("#v_id").val();

                $.ajax({
                    url:"file_edit.php?id="+v_id,
                    cache:false,
                    success:function(result){
                        $(".modal-content").html(result);
                    }
                });
                $("#userModal").modal('show');
                return false;


            });
            $("button").click(function(){

                $(this).closest("div").find("video").toggle();
                $(this).text(function(i, text){
                    return text === "Show Video" ? "Hide Video" : "Show Video";
                });
                return false;
            });
        });
    </script>

</head>
<body>
<form method="post" action="">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-blue">

                <div class="panel-body">
                    <div class="col-md-2">
                        <label>College</label>
                        <select name = "college" id="college" onchange = "selectDept(this.value)"  class="form-control" >
                            <option value="">Select College</option>
                            <?php
                            include('config.php');
                            $q6 = mysql_query("select DISTINCT institution_short_name from api_std where institution_short_name!='' and status=1");
                            while($r = mysql_fetch_array($q6)) {
                                ?>
                                <option value = '<?php echo $r["institution_short_name"]; ?>' ><?php echo strtoupper($r['institution_short_name']); ?></option>
                                <?php
                            }

                            ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Department</label>
                        <select name = "dept" id="department_list" class="form-control" onchange = "getSection(this.value)">

                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Batch</label>
                        <select class="form-control" id="section_list" name="section" required>

                        </select>
                    </div>
                    <div class="col-md-2">
                        <br>
                        <input type="submit" name="submit" value="Search" class="btn btn-primary">
                    </div>
                </div>
            </div>
        </div>
        <?php
        if(isset($_POST['submit'])) {
            $query = "";
            if(empty($_POST['students'])) {
                $query = mysql_query("select api_std.id as uid,student_name,register_no,course,batch,institution_name,
                institution_short_name,api_std.status as ustatus,video1.* from api_std INNER JOIN video1 on
                api_std.id=video1.student_id where api_std.institution_short_name='{$_POST['college']}' and
                api_std.course='{$_POST['dept']}' and api_std.batch='{$_POST['section']}' and video1.status=1");

            }
            else {
                $query = mysql_query("select users.id as uid,name,password,clg_id,dept_id,section_id,batch,role,users.status as ustatus,video1.* from
            users INNER JOIN video1 on users.id=video1.student_id where users.clg_id='{$_POST['college']}' and dept_id='{$_POST['dept']}' and section_id='{$_POST['section']}'
            and batch='{$_POST['batch']}' and student_id='{$_POST['students']}' and video1.status=1");

            }

            ?>
            <center>
                <div class="row" style="margin-left:150px">
                    <div class="col-xs-12">
                        <div class="panel panel-blue">

                            <div class="panel-body" style="background-color: gainsboro;width:1000px">

                                <?php
                                while ($row = mysql_fetch_array($query)) {
                                //echo $row['college_name'];
                                echo "<p><b>Uploaded For:</b> ". $row['student_name'];

                                ?>

                                <div>
                                    <label>Video</label><br>
                                    <video width="500" height="400" controls controlsList="nodownload">
                                        <source src="test/<?php echo $row['v_name']; ?>" type="video/mp4">
                                    </video> <br>
                                    <label>Audio</label><br>
                                    <audio controls controlsList="nodownload">

                                        <source src="test/<?php echo $row['a_name']; ?>">

                                    </audio><br>
                                    <label>Resume</label><br>


                                    <a href="test/<?php echo $row['r_name']; ?>" target="_blank">view file</a>
                                </div>

                                <?php

                                if ($_SESSION['role'] == "Admin" || $_SESSION['role'] == "SSA Admin") {
                                ?>
                                <p><input type="text" name="v_id" id="v_id" value="<?php echo $row['id']; ?>" hidden>
                                    <?php
                                    echo "<a href='' view=''>Edit </a>||";
                                    echo "<a href='file_delete.php?id=" . $row['id'] . "' > Delete</a>";
                                    echo "</p><br>";
                                    }

                                    }
                                    echo "</div>";
                                    echo "<br><br>";


                                    $row = mysql_fetch_assoc($sql);

                                    $total_pages = ceil($row["total"] / $results_per_page); // calculate total pages with results

                                    for ($i = 1; $i <= $total_pages; $i++) {  // print links for all pages
                                        echo "<b><a href='view_files.php?page=" . $i . "'";
                                        if ($i == $page) echo " class='curPage'";
                                        echo ">" . $i . "</a></b> ";
                                    }

                                    echo "</div></center>";
                                    ?>

                            </div>
                        </div>
                    </div>
                </div>
            </center>
            <?php
        }
        ?>
        <div id="userModal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">

                </div>

            </div>

        </div>
</form>
</body>
</html>