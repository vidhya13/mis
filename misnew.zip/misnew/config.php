<?php
$hostname="localhost";
$username="root";
$password="mysql";
$db_name="cloudcoderdb";
$con=mysql_connect($hostname,$username,$password);
mysql_select_db($db_name);

?>