<option value="">Select Section</option>
<?php
include('config.php');
if(isset($_GET['deptid'])) {

    $did = $_GET['deptid'];
    $query = mysql_query("select * from section where dept_id='$did' and status=1");

    while($r = mysql_fetch_array($query)) {
        ?>
        <option value = '<?php echo $r['id']; ?>' <?php if(isset($_GET['sid'] )) { if($_GET['sid']==$r['id']) { echo 'selected'; } } ?>><?php echo strtoupper($r['name']); ?></option>
        <?php
    }
}
?>