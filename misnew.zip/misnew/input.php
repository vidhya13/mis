
<div style="margin:20px">
<DIV class="product-item float-clear" style="padding:20px;clear:both;border:2px solid #808000;width:600px">

<DIV class=""><label><b>Test Input</b></label><input type="text" name="test_input[]" /></DIV><br>
<DIV class="float-left"><label><b>Test Output</b></label><input type="text" name="test_output[]" /></DIV><br>
<DIV class="float-left"><label><b>Secret</b></label>
<input type="checkbox" name="test_index[]" />If checked, the test is secret (not revealed to students)</DIV>

</DIV>
</div>