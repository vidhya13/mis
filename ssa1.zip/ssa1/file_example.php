<?php
$target_dir = "test_upload/";

include('config.php');
//include('header.php');

//$query = mysql_query("select * from users where id='{$_GET['id']}'");
if(isset($_POST['upd'])) {

$target_video = $target_dir . basename($_FILES["VideoToUpload"]["name"]);
$target_audio = $target_dir . basename($_FILES["AudioToUpload"]["name"]);
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

$imageVideoType = pathinfo($target_video,PATHINFO_EXTENSION);
$imageAudioType = pathinfo($target_audio,PATHINFO_EXTENSION);
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

echo basename($_FILES["VideoToUpload"]["name"]);
echo $_FILES["VideoToUpload"]["tmp_name"];

    /* if($imageFileType != "mp4" && $imageFileType != "avi" && $imageFileType != "mov" && $imageFileType != "3gp" && $imageFileType != "mpeg")
    {
        echo "File Format Not Suppoted";
    }

    else
    { */

    $video_path=$_FILES['VideoToUpload']['name'];
    $audio_path=$_FILES['AudioToUpload']['name'];
    $file_path=$_FILES['fileToUpload']['name'];
	echo $video_path;
	echo $audio_path;
	echo $file_path;
	$query = mysql_query("INSERT INTO `video1`(`v_name`, `a_name`, `r_name`, `student_id`) VALUES ('{$video_path}','{$audio_path}',
	'{$file_path}','{$_GET['id']}')");
	 if($query) {
			move_uploaded_file($_FILES["VideoToUpload"]["tmp_name"],$target_video);
			move_uploaded_file($_FILES["AudioToUpload"]["tmp_name"],$target_audio);
            move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$target_file);

            echo "uploaded ";
        }
        else
        {
            die(mysql_error());
        }

    }


?>
<html>
<head>

</head>
<body>
<form id="userForm" method="post" enctype="multipart/form-data">
    <div class="container">
	 <div class="col-md-6 m-t-10">
	<div class="form-group">
                <label>Upload Video</label>
                <input type="file" class="form-control" name="VideoToUpload"/>
            </div>
			<div class="form-group">
                <label>Upload Audio</label>
                <input type="file" class="form-control" name="AudioToUpload"/>
            </div>
			<div class="form-group">
                <label>Upload Resume</label>
                <input type="file" class="form-control" name="fileToUpload"/>
            </div> 
            <div class="form-group">

                <input type="submit" value="Upload" class="btn btn-primary" name="upd" id="upd"/>

                <input type="hidden" value="Preview Video" class="btn btn-info" id="disp" name="disp" />
            </div>

        </div>
    </div>

</form>
</body>
</html>