<?php

?>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$(function(){
	$("ul li").click(function(){
		var val = $(this).text();
		var tot = $("body").find("p").text();
		var new_tot = parseInt(val) + parseInt(tot);
		$("body").find("p").text(new_tot);
});
});
</script>
</head>
<body>
<form method="post">
<center>
<ul>
<li>450</li>
<li>550</li>
<li>650</li>
</ul>
<p>0</p>
</center>
</form>
</body>
</html>