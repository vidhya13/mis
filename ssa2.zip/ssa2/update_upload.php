<?php

include('config.php');

if($_POST) {


    $query = mysql_query("UPDATE `video1` SET `v_name`='{$_POST['sid']}{$_POST['upv']}',
`a_name`='{$_POST['sid']}{$_POST['upa']}',`r_name`='{$_POST['sid']}{$_POST['upf']}',
`student_id`='{$_POST['sid']}' WHERE id='{$_POST['vid']}'");

    }
?>

