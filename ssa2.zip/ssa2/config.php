<?php
$con = mysql_connect("localhost","root","");
mysql_select_db("ssa",$con);
?>