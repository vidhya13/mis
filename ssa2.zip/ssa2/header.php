<html lang="en">
<head>
  <title>KGiSL SSA</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

  <script src=" jquery-1.12.4.js"></script>


  <style>
    .un
    {
      padding-left:500px;
    }
    .l
    {
      padding-left:50px;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KGiSL SSA</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="<?php echo ($page == "home" ? "active" : "")?>"><a href="first.php">Home</a></li>
      <?php if($_SESSION['role'] == "ADMIN") {?>
        <li class="<?php echo ($page == "pro_det" ? "active" : "")?>"><a href="ecampus.php">Add User</a></li>
        <li class="<?php echo ($page == "file" ? "active" : "")?>"><a href="upload_blogs.php">Blogs</a></li>
      <?php } ?>
      <li class="<?php echo ($page == "view_file" ? "active" : "")?>"><a href="upload_view.php">View Blogs</a></li>
    </ul>
    <div class="un">
      <a class="navbar-brand un" href="#"> Welcome <b><?php echo $_SESSION['username']; ?></b></a>
      <a class="navbar-brand l" href="logout.php"> Logout</a>
    </div>
  </div>
</nav>

</body>
</html>