This version of Ace was checked out from:
https://github.com/ajaxorg/ace-builds/

on 2014-07-04

---
updated on 2016-05-01 with a fresh pull from the Git repo

