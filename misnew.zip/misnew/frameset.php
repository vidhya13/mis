<html>
<head>
<style>
</style>
</head>
<body>
<form method="post">
<frameset cols="50%,50%">
<frame src="exercise.php">
<frame src="">
</frameset>
</form>
</body>
</html>