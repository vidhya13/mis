
    var options = {
        enableHighAccuracy: true,
        maximumAge: 3600000
    }
    var watchID = navigator.geolocation.getCurrentPosition(onSuccess, onError, options);

    function onSuccess(position) {
        /*console.log('Latitude: ' + position.coords.latitude + '\n' +
            'Longitude: ' + position.coords.longitude + '\n' +
            'Altitude: ' + position.coords.altitude + '\n' +
            'Accuracy: ' + position.coords.accuracy + '\n' +
            'Altitude Accuracy: ' + position.coords.altitudeAccuracy + '\n' +
            'Heading: ' + position.coords.heading + '\n' +
            'Speed: ' + position.coords.speed + '\n' +
            'Timestamp: ' + position.timestamp + '\n');*/
        current_lat = position.coords.latitude;
        current_lng = position.coords.longitude;
		getlat(current_lat,current_lng);
        //console.log(position.coords);
    };
    function onError(error) {
        alert('code: ' + error.code + '\n' + 'message: ' + error.message + '\n');
    }
function getlat(current_lat,current_lng)
{
			var geocoder = new google.maps.Geocoder();
 
var latLng = new google.maps.LatLng(current_lat,current_lng);
geocoder.geocode({       
        latLng: latLng     
        }, 
        function(responses) 
        {     
           if (responses && responses.length > 0) 
           {        
      $("#current").text(responses[0].formatted_address);             
			 // alert(responses[0].formatted_address);     
           } 
           else 
           {       
             alert('Not getting Any address for given latitude and longitude.');     
           }   
        }
);
}