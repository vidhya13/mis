<html>
<head>
    <style>
        .modal-header {
            background-color: #337AB7;
            color:white;
        }
    </style>
</head>

<script>
    $(document).ready(function(){
        $('#userForm').on('submit', function(ev) {
            var upv = $("#uv").val();
            var upa = $("#ua").val();
            var upf = $("#uf").val();
            var sid = $("#sid").val();
            var vid = $("#vid").val();

            var filename = upv.split("\\").pop();
            var filename1 = upa.split("\\").pop();
            var filename2 = upf.split("\\").pop();
            $.ajax({

                type: 'POST',
                url : "submit_upload.php",
                cache:false,
                data: {upv:filename,upa:filename1,upf:filename2,sid:sid,upv1:upv,vid:vid},
                success: function () {


                },
                error: function() {
                    alert("Thank You For Choosing the Project!! We will allot you with the specified mentor soon..");
                }
            });

        });
    });


    $('#uv').change(function(input){
        var sid = $("#sid").val();

        console.log(input);
        var fvalue = $(this).attr("fid");
        var formData = new FormData();
        formData.append('file', $('input[type=file]')[fvalue].files[0]);
        formData.append('sid',sid);
        console.log("form data " + formData);
        $.ajax({
            url : 'up_file.php',
            data : formData,
            cache:false,
            processData : false,
            contentType : false,
            type : 'POST',
            success : function(data) {
                var a = data;
                if(a) {
                    alert(a);

                    $("#uv").val('');
                }
                }
        });
    });

    $('#ua').change(function(input){
        var sid = $("#sid").val();

        console.log(input);
        var fvalue = $(this).attr("fid");
        var formData = new FormData();
        formData.append('file', $('input[type=file]')[fvalue].files[0]);
        formData.append('sid',sid);
        console.log("form data " + formData);
        $.ajax({
            url : 'up_audio.php',
            data : formData,
            cache:false,
            processData : false,
            contentType : false,
            type : 'POST',
            success : function(data) {
                var a = data;
                if(a) {
                    alert(a);

                    $("#ua").val('');
                }
            }
        });
    });

    $('#uf').change(function(input){
        var sid = $("#sid").val();

        console.log(input);
        var fvalue = $(this).attr("fid");
        var formData = new FormData();
        formData.append('file', $('input[type=file]')[fvalue].files[0]);
        formData.append('sid',sid);
        console.log("form data " + formData);
        $.ajax({
            url : 'up_filedata.php',
            data : formData,
            cache:false,
            processData : false,
            contentType : false,
            type : 'POST',
            success : function(data) {
                var a = data;
                if(a) {
                    alert(a);

                    $("#uf").val('');
                }
            }
        });
    });
</script>
<body>
<form id="userForm" method="post" enctype="multipart/form-data">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title modal-primary">Upload files</h4>

    </div>
    <div class="modal-body">
            <div class="form-group">
                <label>Upload Video</label>
                <input type="file" accept="video/*" class="form-control" id="uv" fid="0" name="VideoToUpload"/>
            </div>
            <div class="form-group">
                <label>Upload Audio</label>
                <input type="file" accept="audio/*" class="form-control" id="ua" fid="1" name="AudioToUpload"/>
            </div>
            <div class="form-group">
                <label>Upload Resume</label>
                <input type="file" accept="doc, docx, pdf" class="form-control" id="uf" fid="2" name="fileToUpload"/>
            </div>
            </div>
    <div class="modal-footer">
            <div class="form-group">

           <!--     <input type="submit" value="Upload" class="btn btn-primary" name="upd" id="upd"/>


                <input type="hidden" value="Preview Video" class="btn btn-info" id="disp" name="disp" />-->
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" name="submit" class="btn btn-default" value="Submit">Submit</button>
                <input type="text" name="sid" id="sid" value="<?php echo $_GET['id']; ?>" hidden>

            </div>
            </div>



</form>
</body>
</html>