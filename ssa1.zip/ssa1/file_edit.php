<?php

session_start();
include('config.php');

error_reporting(1);

extract($_POST);

$target_dir = "test_upload/";

$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

if(isset($_GET['id'])) {


    $query = mysql_query("select * from video where v_id='{$_GET['id']}'");
    $row = mysql_fetch_array($query);


    if($upd)
    {

        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

        /* if($imageFileType != "mp4" && $imageFileType != "avi" && $imageFileType != "mov" && $imageFileType != "3gp" && $imageFileType != "mpeg")
        {
            echo "File Format Not Suppoted";
        }

        else
        { */

        $video_path=$_FILES['fileToUpload']['name'];
        $query1 = mysql_query("SELECT c.id,c.name as college_name,d.id,d.name as department_name,s.id,s.name as section_name,u.name as username,u.clg_id,u.dept_id,u.section_id,u.role from
college c,department d,section s,users u where c.id=u.clg_id and d.id=u.dept_id and s.id=u.section_id and u.id='{$_SESSION['uid']}'");
        $row1 = mysql_fetch_array($query1);
        $query = mysql_query("UPDATE `video` SET `video_name`='{$video_path}',`uploaded_by`='{$_SESSION['username']}',
`category`='{$_POST['category']}',`clg_id`='{$_POST['coll']}',`dept_id`='{$_POST['dept']}',`section_id`='{$_POST['section']}',
`from_clg`='{$row1['college_name']}',`from_dept`='{$row1['department_name']}',`from_section`='{$row1['section_name']}' WHERE v_id='{$_GET['id']}'");

        if($query) {
            move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$target_file);

            echo "uploaded ";
        }
        else
        {
            die(mysql_error());
        }

    }

//display all uploaded video

    if($disp)

    {

        $query=mysql_query("SELECT * FROM video ORDER BY v_id DESC LIMIT 1");

        while($all_video=mysql_fetch_array($query))

        {
            ?>
            <center>
                <video width="600" height="400" controls>
                    <source src="test_upload/<?php echo $all_video['video_name']; ?>" type="video/mp4">
                </video>
            </center>
        <?php } } ?>

    <html>
    <head>
        <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
        <script>
            function selectDept(val) {

                $.ajax({
                    type: "GET",
                    url: "getDepartment.php",
                    cache:false,
                    data: "collegeid=" + val,
                    success: function (data) {

                        $('#department_list').html(data);
                    }
                });
            }
        </script>
        <script>
            function getSection(val) {

                $.ajax({
                    type:"GET",
                    url:"getSection.php",
                    cache:false,
                    data:"deptid="+val,
                    success:function(data) {

                        $("#section_list").html(data);
                    }
                });
            }
        </script>
        <script type="text/javascript">

            $('#userForm').on('submit', function(ev) {
                var image = $('#fileToUpload').val();

                var text = image.split("\\").pop();
                //alert(text);


                var college = $('#coll').val();


                var department = $('#department_list').val();

                var section = $('#section_list').val();

                var category = $('#category').val();


                var id = $('#v_id').val();


                $.ajax({

                    type: 'POST',
                    url : "file_add.php",
                    data: {college:college, department:department, section:section, category:category, image:text, id:id},
                    success: function (data) {
                        alert("Blog Updated Successfully!! Kindly Choose Category and College to view blogs");


                    },
                    error: function() {
                        alert("Thank You For Choosing the Project!! We will allot you with the specified mentor soon..");
                    }
                });


            });
        </script>
        <style>
            .modal-header {
                background-color: #337AB7;
                color:white;
            }
        </style>
    </head>
    <body>
    <form id="userForm" method="post" enctype="multipart/form-data">

        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
            </button>
            <h4 class="modal-title modal-primary">Edit Blogs</h4>

        </div>
        <div class="modal-body">

            <div class="form-group">
                <label>Select College</label>
                <select name = "coll" id="coll" class="form-control" onchange = "selectDept(this.value)">
                    <option value="">Select College</option>
                    <?php

                    $q6 = mysql_query("select * from college");
                    while($r = mysql_fetch_array($q6)) {
                        ?>
                        <option value = '<?php echo $r["id"]; ?>' <?php if($row['clg_id']==$r['id']) { echo 'selected'; } ?>><?php echo $r['name']; ?></option>

                        <?php

                    }

                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Select Department</label>
                <select name = "dept" id="department_list" class="form-control" onchange = "getSection(this.value)">
                    <option value="">Select Department</option>
                    <?php
                    $q6 = mysql_query("select * from department where clg_id='{$row['clg_id']}'");
                    while($r = mysql_fetch_array($q6)) {
                        ?>
                        <option value='<?php echo $r["id"]; ?>' <?php if($row['dept_id']==$r['id']) { echo 'selected'; } ?>><?php echo $r['name']; ?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Section</label>
                <select class="form-control" id="section_list" name="section">
                    <option value="">Select Section</option>
                    <?php
                    $q6 = mysql_query("select * from section where dept_id='{$row['dept_id']}'");
                    while($r = mysql_fetch_array($q6)) {
                        ?>
                        <option value='<?php echo $r["id"]; ?>' <?php if($row['section_id']==$r['id']) { echo 'selected'; } ?>><?php echo $r['name']; ?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Category</label>
                <select class="form-control" name="category" id="category" required>
                    <option value="">Select Category</option>
                    <option value="Project" <?php if($row['category']=="Project") { echo 'selected'; } ?>>Project</option>
                    <option value="Syllabus" <?php if($row['category']=="Syllabus") { echo 'selected'; } ?>>Syllabus</option>
                    <option value="Study Materials" <?php if($row['category']=="Study Materials") { echo 'selected'; } ?>>Study Materials</option>
                </select>
            </div>
            <div class="form-group">
                <label>Upload Video</label>

                <input type="file" name="fileToUpload" id="fileToUpload" value="<?php echo $row['video_name']; ?>"/>
                <span><?php echo $row['video_name']; ?></span>

            </div>
        </div>
        <input type="text" name="v_id" id="v_id" value="<?php echo $row['v_id']; ?>" hidden>
        <!--<div class="form-group">

            <input type="submit" value="Submit" class="btn btn-primary" name="upd"/>

            <input type="submit" value="Preview Video" class="btn btn-info" name="disp"/>
        </div>-->
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" name="submit" class="btn btn-default" value="Submit">Submit</button>
        </div>


    </form>
    <div id="a">
    </div>
    </body>
    </html>
<?php } ?>