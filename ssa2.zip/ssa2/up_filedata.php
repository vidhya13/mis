<?php

$sid = $_POST['sid'];
/* $sub_dir = "test/".$sid."/";
if(!is_dir($sub_dir))
  {
  mkdir($sub_dir);

  } */

$target_video = "test/".$sid . basename($_FILES['file']['name']);
$imageFileType = pathinfo($target_video,PATHINFO_EXTENSION);
if($imageFileType != "doc" && $imageFileType != "docx" && $imageFileType != "pdf")
{
    echo "Resume format must be document or pdf";

}
else {
    move_uploaded_file($_FILES['file']['tmp_name'], $target_video);

}
/* $target_video = $sub_dir . basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'],$target_video);
echo $_FILES['file']['tmp_name'];

echo $_POST['sid']; */
?>