<option value="">Select Department</option>
<?php
include('config.php');
if(isset($_GET['collegeid'])) {

    $cid = $_GET['collegeid'];
    $query = mysql_query("select DISTINCT course from api_std where institution_short_name='$cid' and status=1");

    while($r = mysql_fetch_array($query)) {
        ?>
        <option value = '<?php echo $r["course"]; ?>'><?php echo strtoupper($r['course']); ?></option>
        <?php
    }
}
?>