<?php
session_start();
$page = "pro_det";
error_reporting(1);
include('config.php');
include('header.php');
$q1 = "";
$r1 = "";
if(!empty($_GET['id'])) {
    $q1 = mysql_query("SELECT u.*,c.id as cid,c.name as college_name,d.name as dept_name,s.id as sid,s.name as section_name
 from users u, college c,department d,section s where u.clg_id=c.id and u.dept_id=d.id and s.id=u.section_id and u.status=1 and u.id='{$_GET['id']}'");
    $r1 = mysql_fetch_array($q1);
    if(isset($_POST['submit'])) {
        $query = mysql_query("UPDATE `users` SET `name`='{$_POST['uname']}',`password`='{$_POST['roll_no']}',`clg_id`='{$_POST['college']}',
`dept_id`='{$_POST['dept']}',`section_id`='{$_POST['section']}',`role`='{$_POST['role']}' WHERE id='{$_GET['id']}'");
        if($query) {
            header('location:pro_det.php');
        }
    }
}
else {
    if(isset($_POST['submit'])) {
        if(!empty($_POST)) {

            $query = mysql_query("INSERT INTO `users`( `name`, `password`, `clg_id`, `dept_id`, `section_id`, `batch`, `role`)
		VALUES ('{$_POST['uname']}','{$_POST['roll_no']}','{$_POST['college']}','{$_POST['dept']}','{$_POST['section']}','{$_POST['batch']}','{$_POST['role']}')");
            if($query) {
                header('location:pro_det.php');

            }
            else
            {
                echo "failure";
            }

        }

    }
}
?>

<html>
<head>

    <script>
        $(function(){
            $("body").on("click","[view]",function(){
                window.location.href=$(this).href();
                return false;
                $('#college').trigger('change');
                $('#department_list').trigger('change');




            });

        });

    </script>
    <script>
        function selectDept(val) {
            //  alert(val);
            var cid = $("#cid").val();
            $.ajax({
                type: "GET",
                url: "getDepartment.php",
                cache:false,
                data: {collegeid: val,cid:cid},
                success: function (data) {

                    $('#department_list').html(data);
                }
            });
        }
    </script>
    <script>
        function getSection(val) {
            var sid = $("#sid").val();
            $.ajax({
                type:"GET",
                url:"getSection.php",
                cache:false,
                data:{deptid:val,sid:sid},
                success:function(data) {

                    $("#section_list").html(data);
                }
            })
        }
    </script>


</head>
<body>
<form method="post" action="">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-blue">

                <div class="panel-body">
                    <div class="col-md-2">
                        <label>College</label>
                        <select name = "college" id="college" onchange = "selectDept(this.value)"  class="form-control" >
                            <option value="">Select College</option>
                            <?php
                            include('config.php');
                            $q6 = mysql_query("select * from college where status=1");
                            while($r = mysql_fetch_array($q6)) {
                                ?>
                                <option value = '<?php echo $r["id"]; ?>' <?php if(isset($_GET['id'] )) { if($r1['cid']==$r['id']) { echo 'selected'; } } ?>><?php echo strtoupper($r['name']); ?></option>
                                <?php
                            }

                            ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Department</label>
                        <select name = "dept" id="department_list" class="form-control" onchange = "getSection(this.value)">

                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Section</label>
                        <select class="form-control" id="section_list" name="section" required>

                        </select>
                    </div>
					<div class="col-md-2">
                        <label>Batch</label>
                        <select class="form-control" id="batch_list" name="batch" required>
							<option value="2014">2014</option>
							<option value="2015">2015</option>
							<option value="2016">2016</option>
							<option value="2017">2017</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Name</label>
                        <input type="text" name="uname" <?php if(isset($_GET['id'])) { ?> value="<?php echo $r1['name']; ?>" <?php } ?> class="form-control" required>
                    </div>
                    <div class="col-md-2">
                        <label>RollNo</label>
                        <input type="text" name="roll_no" <?php if(isset($_GET['id'])) { ?> value="<?php echo $r1['password']; ?>" <?php } ?> class="form-control">
                    </div>
                    <div class="col-md-2">
                        <label>Role</label>
                        <select class="form-control" name="role" required>
                            <option value="">Select Role</option>
                            <?php
                            $query = mysql_query("select * from roles where status=1");
                            while($row = mysql_fetch_array($query))
                            {
                                ?>
                                <option value="<?php echo strtoupper($row['role_name']); ?>" <?php  if(isset($_GET['id'] )) { if(strtoupper($r1['role'])==strtoupper($row['role_name'])) { echo 'selected'; } } ?>><?php echo strtoupper($row['role_name']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <br>
                        <input type="submit" name="submit" value="Submit" class="btn btn-primary">
                    </div>
                </div>
            </div>
        </div>

        <input type="text" value = "" name = "sel_value" id="sel_value" hidden>
        <input type="text" id="cid" name="cid" value="<?php echo $r1['dept_id']; ?>" hidden>
        <input type="text" id="sid" name="sid" value="<?php echo $r1['section_id']; ?>" hidden>
        <table id="dynamic-table" class="table table-striped table-bordered table-hover table-responsive" style="margin:10px">
            <thead>
            <tr>
                <th>SNO</th>
                <th>College</th>
                <th>Department</th>
                <th>Section</th>
                <th>Name</th>
                <th>RollNo</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
            </thead>
            <?php
            $q = mysql_query("SELECT u.*,c.id as cid,c.name as college_name,d.name as dept_name,s.id as sid,s.name as section_name
 from users u, college c,department d,section s where u.clg_id=c.id and u.dept_id=d.id and s.id=u.section_id and u.status=1");
            $i = 1;
            while($r = mysql_fetch_array($q)) {
                ?>
                <tbody>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo strtoupper($r['college_name']); ?></td>
                    <td><?php echo strtoupper($r['dept_name']); ?></td>
                    <td><?php echo strtoupper($r['section_name']); ?></td>
                    <td><?php echo strtoupper($r['name']); ?></td>
                    <td><?php echo strtoupper($r['password']); ?></td>
                    <td><?php echo strtoupper($r['role']); ?></td>
                    <td><a href="pro_det.php?id=<?php echo $r['id']; ?>" id="ed" view='' class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i>Edit </a>

                        <a href="delete_user.php?id=<?php echo $r['id']; ?>" class="btn btn-xs btn-danger"> <i class="glyphicon glyphicon-trash"></i>Delete</a></td>

                </tr>
                </tbody>

                <?php
                $i++;
            }
            ?>
        </table>

</form>
</body>
</html>