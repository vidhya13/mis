<?php
session_start();
include('config.php');
include('header.php');
?>

<html>
<head>
    <style>
        #con {
            margin:300px;
            margin-left:500px;
        }
    </style>
</head>
<body>
<div id="con">
    <h1>Welcome to KGiSL-SSA</h1>
</div>
</body>
</html>
