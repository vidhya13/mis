<?php
error_reporting(1);
include('config.php');
include('header.php');

?>
<html>
<head>

    <script>
    $(function() {
            $("body").on("click","[view]",function(){
                var u_id = $(this).closest("tr").find("#uid").text();

                $.ajax({
                    url:"upload_popup.php?id="+u_id,
                    cache:false,
                    success:function(result){
                        $(".modal-content").html(result);
                    }
                });
                $("#userModal").modal('show');
                return false;


            });
            });

    </script>
    <script>
        function selectDept(val) {
            //  alert(val);
            var cid = $("#cid").val();
            $.ajax({
                type: "GET",
                url: "getDepartment.php",
                cache:false,
                data: {collegeid: val,cid:cid},
                success: function (data) {

                    $('#department_list').html(data);
                }
            });
        }
    </script>
    <script>
        function getSection(val) {
            var sid = $("#sid").val();
            $.ajax({
                type:"GET",
                url:"getSection.php",
                cache:false,
                data:{deptid:val,sid:sid},
                success:function(data) {

                    $("#section_list").html(data);
                }
            })
        }
    </script>


</head>
<body>
<form method="post" action="">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-blue">

                <div class="panel-body">
                    <div class="col-md-2">
                        <label>College</label>
                        <select name = "college" id="college" onchange = "selectDept(this.value)"  class="form-control" >
                            <option value="">Select College</option>
                            <?php
                            include('config.php');
                            $q6 = mysql_query("select * from college where status=1");
                            while($r = mysql_fetch_array($q6)) {
                                ?>
                                <option value = '<?php echo $r["id"]; ?>' <?php if(isset($_GET['id'] )) { if($r1['cid']==$r['id']) { echo 'selected'; } } ?>><?php echo strtoupper($r['name']); ?></option>
                                <?php
                            }

                            ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Department</label>
                        <select name = "dept" id="department_list" class="form-control" onchange = "getSection(this.value)">

                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Section</label>
                        <select class="form-control" id="section_list" name="section" required>

                        </select>
                    </div>
					<div class="col-md-2">
                        <label>Batch</label>
                        <select class="form-control" id="batch_list" name="batch" required>
							<option value="2014">2014</option>
							<option value="2015">2015</option>
							<option value="2016">2016</option>
							<option value="2017">2017</option>
                        </select>
                    </div>
					<div class="col-md-2">
                        <br>
                        <input type="submit" name="submit" value="Search" class="btn btn-primary">
                    </div>
                </div>
            </div>
        </div>
		<?php
		if(isset($_POST['submit'])) {
	$query = mysql_query("select * from users where clg_id='{$_POST['college']}' and dept_id='{$_POST['dept']}' and section_id='{$_POST['section']}' and batch='{$_POST['batch']}'");

?>
		<center>
		<table border="1px solid black">
		<tr>
		<th>Student Name</th>
		<th>RollNo</th>
		<th>Action</th>
		</tr>
		<?php
		while($row=mysql_fetch_array($query)) {
		?>
		<tr>
		<td hidden id="uid"> <?php echo $row['id']; ?></td>
		<td id="uuid"><?php echo $row['name'];?></td>
		<td><?php echo $row['password'];?></td>
		<td><a href="" view=''>Upload Video</a></td>
		</tr>
		<?php
		}
		?>
		
		</table>
		</center>
			<?php
		}
		?>
		        <div id="userModal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">

                </div>

            </div>

        </div>
		</form>
</body>
</html>