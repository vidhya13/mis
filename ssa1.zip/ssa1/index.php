<?php
include('config.php');
session_start();
if(isset($_POST['submit'])) {
    $query = mysql_query("select * from users where name='{$_POST['form-username']}' and password='{$_POST['form-password']}'");
    $row = mysql_fetch_array($query);
    $_SESSION['username'] = $row['name'];
    $_SESSION['uid'] = $row['id'];
    $_SESSION['role'] = $row['role'];
    if($query) {
        header("location:first.php");
    }
    else
    {
        echo "Invalid login";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<meta charset="utf-8" />
	<title>untitled</title>
	<meta name="generator" content="Geany 1.25" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  		<style> .Table
    {
        display: table;
		margin: auto;
    }
    .Title
    {
        display: table-caption;
        text-align: center;
        font-weight: bold;
        font-size: larger;
    }
    .Heading
    {
        display: table-row;
        font-weight: bold;
        text-align: center;
    }
    .Row
    {
        display: table-row;
    }
    .Cell
    {
        display: table-cell;
        border: solid;
        border-width: thin;
        padding-left: 15px;
        padding-right: 15px;
		padding-top: 0px;
		padding-bottom: 0px;
    }
	
.hover {
        border: 3px dashed red;
}
.sublist
    {
        display: table-cell;
        padding-left: 15px;
        padding-right: 15px;
		padding-top: 0px;
		padding-bottom: 0px;
    }
#content{
	width: 600px;
	margin: auto;
	margin-top: 100px;
}
#form{
	padding: 10px;
	background: #f7f7f7;
	border: 1px solid #ccc;
	border-radius: 4px;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
}

#login{
	width: 600px;
	margin: auto;
	background: #f7f7f7;
}
</style>

 
</script>
</head>
<body>


<nav class="navbar navbar-default navbar-static-top">
	  <div class="container">
	  <h3>KGiSL-SSA Portal</h3>
	  </div>
	</nav>
	
	<div id="content">
		<div id="form">
		<form class="form-horizontal" method="post">
			<fieldset>

			<!-- Form Name -->
			<legend>Login Here</legend>

			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="username">Username</label>  
			  <div class="col-md-4">
			  <input type="text" name="form-username" id="text1"  autocomplete="off" placeholder="" class="form-control input-md" required="">
				
			  </div>
			</div>

			<!-- Password input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="password">Password</label>
			  <div class="col-md-4">
				<input type="password" name="form-password" autocomplete="off" id="text2" placeholder="" class="form-control input-md" required="">
				
			  </div>
			</div>

			<!-- Button -->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="login"></label>
			  <div class="col-md-4">
			<button type="submit" name="submit" class="btn btn-success">Sign In</button>
			  </div>
			</div>
			

			</fieldset>
		</form>
		</div>
	</div>

</body>

</html>