<?php
include('config.php');
if(isset($_GET['id'])) {
    $query = mysql_query("update category set status=0 where id='{$_GET['id']}'");
    if($query) {
        header('location:category.php');
    }
}
?>