<option value="">Select Department</option>
<?php
include('config.php');
if(isset($_GET['collegeid'])) {

    $cid = $_GET['collegeid'];
    $query = mysql_query("select * from department where clg_id='$cid' and status=1");

    while($r = mysql_fetch_array($query)) {
        ?>
        <option value = '<?php echo $r["id"]; ?>' <?php if(isset($_GET['cid'] )) { if($_GET['cid']==$r['id']) { echo 'selected'; } } ?>><?php echo strtoupper($r['name']); ?></option>
        <?php
    }
}
?>