
<?php include('common/header.php'); ?>
<html>
<head>
</head>
<body>
<h1>Organic Wood Pressed Coconut Oil</h1>
<div>
<h4>Making of Wood Pressed Coconut Oil: Price 1000 ML 230 / 500 ML 120 </h4>

<p>First the fresh coconut meat is grated and then Sun dried. This drying process, however, seems to be important to the resulting taste and quality of the oil.</p>

  <pre>  This dried coconut is then placed into a Wood press (Marachekku) and pressed.
    This pressing yields oil with proteins.
    These Oil are allowed to “Settle” in settling tanks for 4 days.
    Oil is filtered & Packed, No Refinement Process & No Sulphur added </pre>

<h4>Benefits of Coconut Oil:</h4>

 <pre>   Skin Care: Coconut oil is an excellent nourishing ointment & effective moisturizer on all types of skins.
    Hair Care: Coconut oil is one of the best natural nutrition for hair. It provides the essential proteins required for nourishing damaged hair, helps in healthy growth of hair and gives a shiny luster.
    Liver, Kidney and Gall Bladder Health: Medium Chain Fatty Acid (MCFAs) in coconut oil reduce workload on the liver and support its function by preventing accumulation of fat. Coconut oil also helps in preventing kidney and gall bladder diseases. It is a remedy in dissolving kidney stones.
    Heart Diseases: Coconut oil is highly beneficial for the cardio vascular system. It helps in strengthening the heart’s muscular structures.
    Enhanced Metabolism and Energy: Boosts energy and endurance, remedy for treating pancreatitis.
    Immune System: With antifungal, antimicrobial, antibacterial and antiviral properties, coconut oil strengthens the immune system.
    Bone Health: Coconut oil improves the ability of our body to absorb the needed minerals like calcium and magnesium.
    Healing Wounds & Burns: It promotes fast healing and recovery from cuts and burns. </pre>

</div>

</body>
</html>
