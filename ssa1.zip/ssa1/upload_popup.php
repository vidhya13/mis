<?php
$target_dir = "test/";

include('config.php');
//include('header.php');

//$query = mysql_query("select * from users where id='{$_GET['id']}'");

	

if(isset($_GET['id'])) {
if(isset($_POST['upd'])) {

$target_video = $target_dir . basename($_FILES["VideoToUpload"]["name"]);
$target_audio = $target_dir . basename($_FILES["AudioToUpload"]["name"]);
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

$imageVideoType = pathinfo($target_video,PATHINFO_EXTENSION);
$imageAudioType = pathinfo($target_audio,PATHINFO_EXTENSION);
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

    /* if($imageFileType != "mp4" && $imageFileType != "avi" && $imageFileType != "mov" && $imageFileType != "3gp" && $imageFileType != "mpeg")
    {
        echo "File Format Not Suppoted";
    }

    else
    { */

    $video_path=$_FILES['VideoToUpload']['name'];
    $audio_path=$_FILES['AudioToUpload']['name'];
    $file_path=$_FILES['fileToUpload']['name'];
	echo $video_path;
	echo $audio_path;
	echo $file_path;
	$query = mysql_query("INSERT INTO `video1`(`v_name`, `a_name`, `r_name`, `student_id`) VALUES ('{$video_path}','{$audio_path}',
	'{$file_path}','{$_GET['id']}')");
	 if($query) {
			move_uploaded_file($_FILES["VideoToUpload"]["tmp_name"],$target_video);
			move_uploaded_file($_FILES["AudioToUpload"]["tmp_name"],$target_audio);
            move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$target_file);

            echo "uploaded ";
        }
        else
        {
            die(mysql_error());
        }
		
		
    }
}

?>
<html>
<head>

</head>

<script>
$(document).ready(function(){
$('#userForm').on('submit', function(ev) {
var upv = $("#uv").val();
var upa = $("#ua").val();
var upf = $("#uf").val();
var sid = $("#sid").val();
var vid = $("#vid").val();
/* filename = "";
filename1 = "";
filename2 = ""; */
var filename = upv.split("\\").pop();
var filename1 = upa.split("\\").pop();
var filename2 = upf.split("\\").pop();


/*if (upv) {
    var startIndex = (upv.indexOf('\\') >= 0 ? upv.lastIndexOf('\\') : upv.lastIndexOf('/'));
    var filename = upv.substring(startIndex);
    if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
        filename = filename.substring(1);
    }
   
} 
if (upa) {
    var startIndex = (upa.indexOf('\\') >= 0 ? upa.lastIndexOf('\\') : upa.lastIndexOf('/'));
    var filename1 = upa.substring(startIndex);
    if (filename1.indexOf('\\') === 0 || filename1.indexOf('/') === 0) {
        filename1 = filename1.substring(1);
    }
   
}
if (upf) {
    var startIndex = (upf.indexOf('\\') >= 0 ? upf.lastIndexOf('\\') : upf.lastIndexOf('/'));
    var filename2 = upf.substring(startIndex);
    if (filename2.indexOf('\\') === 0 || filename2.indexOf('/') === 0) {
        filename2 = filename2.substring(1);
    }
   
} */
alert(filename2);
alert(vid);
$.ajax({

                type: 'POST',
                url : "submit_upload.php",
				cache:false,
                data: {upv:filename,upa:filename1,upf:filename2,sid:sid,upv1:upv,vid:vid},
                success: function () {
                    alert();

                },
                error: function() {
                    alert("Thank You For Choosing the Project!! We will allot you with the specified mentor soon..");
                }
            });

});
});


$('input[type="file"]').change(function(input){
 var sid = $("#sid").val();
    	   //alert( $("#thread").val());
		   console.log(input);
     var fvalue = $(this).attr("fid");
	 alert(fvalue);
            var formData = new FormData();
            formData.append('file', $('input[type=file]')[fvalue].files[0]);
			formData.append('sid',sid);
            console.log("form data " + formData);
            $.ajax({
                url : 'up_file.php',
               // url : '/uploadFile',
                data : formData,
				cache:false,
                processData : false,
                contentType : false,
                type : 'POST',
                success : function(data) {
                    //alert("File Uploaded successfully");
                   // alert(data);
					fvalue = "";
                }
                
            });
	

});

</script> 
<body>
<form id="userForm" method="post" enctype="multipart/form-data">
    <div class="container">
	 <div class="col-md-6 m-t-10">
	<div class="form-group">
                <label>Upload Video</label>
                <input type="file" accept="video/*" class="form-control" id="uv" fid="0" name="VideoToUpload" onchange="readURL(this)"/>
            </div>
			<div class="form-group">
                <label>Upload Audio</label>
                <input type="file" accept="audio/*" class="form-control" id="ua" fid="1" name="AudioToUpload" onchange="readURL(this)"/>
            </div>
			<div class="form-group">
                <label>Upload Resume</label>
                <input type="file" accept="doc, docx, pdf" class="form-control" id="uf" fid="2" name="fileToUpload" onchange="readURL(this)"/>
            </div> 
            <div class="form-group">

                <input type="submit" value="Upload" class="btn btn-primary" name="upd" id="upd"/>
				

                <input type="hidden" value="Preview Video" class="btn btn-info" id="disp" name="disp" />
				
				<input type="text" name="sid" id="sid" value="<?php echo $_GET['id']; ?>" hidden>
				
            </div>

        </div>
    </div>

</form>
</body>
</html>