<?php
session_start();
$page = "pro_det";
error_reporting(1);
include('config.php');
include('header.php');
if(!empty($_POST)) {
if(isset($_POST['submit'])) {
	$api_url ="http://ecampus.kgisliim.ac.in/eCampusAPI/getStudentInfo.php";
	$username='ecampus';
	$password='ecampus@123';
	$register_no=$_POST['regno'];  //711715205035

	$curl_handle=curl_init();
	curl_setopt($curl_handle,CURLOPT_URL, $api_url);
	curl_setopt($curl_handle, CURLOPT_HTTPHEADER, array ('X_ECAMPUSAPI_USERNAME: '.$username, 'X_ECAMPUSAPI_PASSWORD: '.$password));
	curl_setopt($curl_handle, CURLOPT_POST, 1);
	curl_setopt($curl_handle, CURLOPT_POSTFIELDS,"action=getStudentUnivResultInfo&register_no=". $register_no);
	curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
	$response = curl_exec($curl_handle);
	$data = json_decode($response,TRUE);

	curl_close ($curl_handle);

	$q = mysql_query("INSERT INTO `api_std`(`register_no`, `student_name`, `course`, `batch`, `institution_name`, `institution_short_name`,`role`) VALUES (
'{$data['StudentInfo']['register_no']}','{$data['StudentInfo']['student_name']}','{$data['StudentInfo']['course']}',
'{$data['StudentInfo']['batch']}','{$data['StudentInfo']['institution_name']}','{$data['StudentInfo']['institution_short_name']}','STUDENT')");
	if($q) {
		echo "<script>alert('success');</script>";
	}
	else {
		echo "<script>alert('fail');</script>";
	}
}
}
?>


<html>
<head>

    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">

    <script src=" //code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>

</head>
<body>
<form method="post">

		<div class="row">
			<div class="col-xs-12">
				<div class="panel panel-blue">
					<div class="panel-heading" style="background-color: chocolate">
						<div class="panel-heading-btn">


						</div>
						<h4 class="panel-title">Add Students</h4></div>
					<div class="panel-body" style="background-color:mistyrose ">
						<div class="col-md-4">
							<label>Enter Register Number</label>

							<input type="text" name="regno" class="form-control">
						</div>
						<div class="col-md-2">
							<br>
							<p><input type="submit" name="submit" value="Submit" class="btn btn-primary"></p>
						</div>
					</div>
				</div>
			</div>
		</div>
<table id="user-table">
	<thead>
    <tr>
	<th>Register Number</th>
	<th>Student Name</th>
	<th>Course</th>
	<th>Batch</th>
	<th>Institution</th>
    </tr>
	</thead>

	<?php
	$query = mysql_query("select * from api_std where batch!=''");
	while($row = mysql_fetch_array($query)) {
		?>
        <tbody>
	<tr>
		<td><?php echo $row['register_no']; ?></td>
		<td><?php echo $row['student_name']; ?></td>
		<td><?php echo $row['course']; ?></td>
		<td><?php echo $row['batch']; ?></td>
		<td><?php echo $row['institution_short_name']; ?></td>
		</tr>
        </tbody>
	<?php
	}
	?>
</table>
    <script>
        $(document).ready(function() {
            $('#user-table').DataTable();
        });
    </script>
</form>
</body>
</html>