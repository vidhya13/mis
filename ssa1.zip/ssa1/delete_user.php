<?php
include('config.php');
if(isset($_GET['id'])) {
    $query = mysql_query("update users set status=0 where id='{$_GET['id']}'");
    if($query) {
        header('location:pro_det.php');
    }
}
?>