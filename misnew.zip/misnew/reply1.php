<?php
$sname='';
          if(isset($_GET['section_name'])){
            $sname = $_GET['section_name'];
        }
        echo $sname;
?>